
## !! 디버그 !!
```bash
# docker image 강제 pull 명령어
kubectl patch deployment -n rookies-app <deployment name> -p "{\"spec\":{\"template\":{\"metadata\":{\"annotations\":{\"date\":\"`date +'%s'`\"}}}}}"

# debug 용 pod 만들기
kubectl run curl-debug --rm -it --restart=Never --image=curlimages/curl -n rookies-app -- sh
```

## 배포 순서
### 0. secret 설정


### 1. namespace 제작
```bash
kubectl apply -f gke-namespace-settings.yaml
```
### 2. 저장소 pv, pvc 제작
```bash
kubectl apply -f gke-pv-pvc-settings.yaml
```
### 3. 네트워크 service 제작
```bash
kubectl apply -f gke-service-settings.yaml
```
### 4. 배포 server 제작
```bash
kubectl apply -f ./mariadb_server/mariadb-deployment.yaml
kubectl apply -f ./file_server/file-server-deployment.yaml
kubectl apply -f ./client_server/client-server-deployment.yaml
kubectl apply -f ./api_server/api-server-deployment.yaml
kubectl apply -f ./ai_server/ai-server-deployment.yaml
```
### 5 healthcheck 제작
```bash
kubectl apply -f gke-backend-config.yaml  
```

### 6. HTTP Route 를 위한 ingress 설정
```bash
kubectl apply -f gke-ingress-settings.yaml
```

### 7. SSL 를 위한 managedCertificate 설정
```bash
kubectl apply -f gke-managed-certificate.yaml
```

